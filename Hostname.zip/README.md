# Systemless Hostname

You can set a custom hostname by editing the hostname file in the modules private directory
The default hostname is your device model name
